# life series
 rehashed life series for personal consumption :3
